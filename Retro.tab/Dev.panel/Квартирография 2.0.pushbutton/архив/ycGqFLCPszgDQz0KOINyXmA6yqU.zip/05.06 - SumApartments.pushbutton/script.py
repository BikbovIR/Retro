# -*- coding: utf-8 -*-
__title__ = "05.06 - Apartments Sum"
__doc__ = """
_____________________________________________________________________
Description:
Apply Revit API Basics to create a tool.

The tool will calculate apartment room sums based on 2 parameters:
- Flat #
- Space Type (Living, Balkon...)

Then sums will be written in all rooms with the same flat number, 
so any room can be tagged to get this information on the plan.

Happy Coding!
_____________________________________________________________________
Author: Erik Frits"""

# ╦╔╦╗╔═╗╔═╗╦═╗╔╦╗╔═╗
# ║║║║╠═╝║ ║╠╦╝ ║ ╚═╗
# ╩╩ ╩╩  ╚═╝╩╚═ ╩ ╚═╝ IMPORTS
# ==================================================
from Autodesk.Revit.DB import *
from pyrevit import forms

# ╦  ╦╔═╗╦═╗╦╔═╗╔╗ ╦  ╔═╗╔═╗
# ╚╗╔╝╠═╣╠╦╝║╠═╣╠╩╗║  ║╣ ╚═╗
#  ╚╝ ╩ ╩╩╚═╩╩ ╩╚═╝╩═╝╚═╝╚═╝ VARIABLES
# ==================================================
doc   = __revit__.ActiveUIDocument.Document #type: Document
uidoc = __revit__.ActiveUIDocument
app   = __revit__.Application

# Global Variables
p_name_room_sorting = 'Top'

p_name_wnf    = '[Σ] - WNF'		#- Output Living Area
p_name_balkon = '[Σ] - Balkon' 	#- Output Balkon Area

# ╔╦╗╔═╗╦╔╗╔
# ║║║╠═╣║║║║
# ╩ ╩╩ ╩╩╝╚╝ MAIN
# ==================================================

# 1. Get All Rooms
all_rooms = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_Rooms).ToElements()

# 2. Sort By Apartment Number
from collections import defaultdict
dict_rooms = defaultdict(list)

for room in all_rooms:
    try:
        top = room.LookupParameter(p_name_room_sorting).AsString()
        if top:
            dict_rooms[top].append(room)
    except:
        forms.alert("Couldn't Read 'Top' Parameter. Please Check and Try Again.", exitscript=True)

# Check Dictionary
# for k,v in dict_rooms.items():
#     print(k,v)

t = Transaction(doc, 'Sum Apartments')
t.Start()

for top, rooms in dict_rooms.items():
    sum_wnf_m2    = 0
    sum_balkon_m2 = 0

    # 3. Sum Apartment Area
    for room in rooms:
        room_type    = room.get_Parameter(BuiltInParameter.ROOM_OCCUPANCY).AsString()
        room_area_m2 = UnitUtils.ConvertFromInternalUnits(room.Area, UnitTypeId.SquareMeters)
        room_area_m2 = round(room_area_m2, 2)

        if room_type == 'WNF':
            # sum_wnf_ft += room.Area
            sum_wnf_m2 += room_area_m2

        elif room_type == 'Balkon':
            # sum_balkon_ft += room.Area
            sum_balkon_m2 += room_area_m2
        else:
            print('Wrong Value: {}'.format(room_type))

    # Preview Results
    print('Apartment Number: {}'.format(top))
    print('SUM Living Space: {}'.format(sum_wnf_m2))
    print('SUM Balkon Space: {}'.format(sum_balkon_m2))
    print('---')


    # Converting M2 to FT
    sum_wnf_ft    = UnitUtils.ConvertToInternalUnits(sum_wnf_m2,    UnitTypeId.SquareMeters)
    sum_balkon_ft = UnitUtils.ConvertToInternalUnits(sum_balkon_m2, UnitTypeId.SquareMeters)


    # 4. Write Results to Output Parameter
    for room in rooms:
        try:
            p_wnf    = room.LookupParameter(p_name_wnf)
            p_balkon = room.LookupParameter(p_name_balkon)

            p_wnf.Set(sum_wnf_ft)
            p_balkon.Set(sum_balkon_ft)
        except:
            forms.alert("Couldn't get Output parameters. Please check and try again", exitscript=True)

t.Commit()